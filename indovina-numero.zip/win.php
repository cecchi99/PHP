<!doctype html>
<html>
  <head>
    <title>Gioco dell'indovina-numero</title>
  </head>
  <body>
    <h1>Gioco dell'indovina-numero</h1>
    <h2>BRAVO!<h2>
    <?php 
      
    ?>
  </body>
</html>